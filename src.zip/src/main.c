/*
    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
    Copyright (c) 2012 - 2022 Xilinx, Inc. All Rights Reserved.
	SPDX-License-Identifier: MIT


    http://www.FreeRTOS.org
    http://aws.amazon.com/freertos


    1 tab == 4 spaces!
 */

/* FreeRTOS includes. */

//#define testingCampaign
#define FAULTDETECTOR_EXECINSW

#include "FreeRTOS.h"
#include "task.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "portable.h"
#include "scaling_image.h"

/*-----------------------------------------------------------*/

#include <math.h>
static void prvTaskOne( void *pvParameters );
static void prvTaskTwo( void *pvParameters );
static void prvTaskThree( void *pvParameters );
static void prvTaskFour( void *pvParameters );
//static void prvImgAcquireAndScaleTask( void *pvParameters );
#include <stdio.h>


static FAULTDETECTOR_region_t trainedRegions[FAULTDETECTOR_MAX_CHECKS][FAULTDETECTOR_MAX_REGIONS];
static u8 n_regions[FAULTDETECTOR_MAX_CHECKS];

#ifdef testingCampaign
u8 injectingErrors=0;
#endif


int main( void )
{
	//		xRTTaskCreate( prvTaskOne,
	//				( const char * ) "One",
	//				configMINIMAL_STACK_SIZE,
	//				NULL,
	//				tskIDLE_PRIORITY,
	//				NULL,
	//				50000000, //deadline
	//				50000000, //period
	//				40000000); //wcet
	//
	//		xRTTaskCreate( prvTaskTwo,
	//				( const char * ) "Two",
	//				configMINIMAL_STACK_SIZE,
	//				NULL,
	//				tskIDLE_PRIORITY,
	//				NULL,
	//				100000000, //deadline
	//				100000000, //period
	//				40000000); //wcet
	//
	//		xRTTaskCreate( prvTaskThree,
	//				( const char * ) "Three",
	//				configMINIMAL_STACK_SIZE,
	//				NULL,
	//				tskIDLE_PRIORITY,
	//				NULL,
	//				150000000, //deadline
	//				150000000, //period
	//				40000000); //wcet


	//	xRTTaskCreate( prvImgAcquireAndScaleTask,
	//			( const char * ) "Four",
	//			configMINIMAL_STACK_SIZE,
	//			NULL,
	//			tskIDLE_PRIORITY,
	//			NULL,
	//			999999997, //deadline
	//			999999997, //period
	//			999999997); //wcet

	xRTTaskCreate( prvTaskFour,
			( const char * ) "Four",
			configMINIMAL_STACK_SIZE,
			NULL,
			tskIDLE_PRIORITY,
			NULL,
			999999997, //deadline
			999999997, //period
			999999997); //wcet

	for (int i=0; i<FAULTDETECTOR_MAX_CHECKS; i++) {
		n_regions[i]=5;
		for (int j=0; j<FAULTDETECTOR_MAX_REGIONS; j++) {
			for (int k=0; k<FAULTDETECTOR_MAX_AOV_DIM; k++) {
				trainedRegions[i][j].center[k]=2.0;
				//				trainedRegions[i][j].max[k]=100.0;
				//				trainedRegions[i][j].min[k]=-100.0;
				trainedRegions[i][j].max[k]=3.0;
				trainedRegions[i][j].min[k]=1.0;
			}
		}

	}

	vTaskStartFaultDetector(0, //do not load from sd, load from supplied trainedRegions and n_regions instead
			trainedRegions,
			n_regions);
	vTaskStartScheduler();

	//should never reach this point
	for( ;; );
}


/*-----------------------------------------------------------*/
static void prvTaskOne( void *pvParameters )
{
	for (;;) {
		xil_printf(" One ");

		vTaskJobEnd();
	}
}

/*-----------------------------------------------------------*/
static void prvTaskTwo( void *pvParameters )
{
	for (;;) {
		xil_printf(" Two ");

		vTaskJobEnd();
	}
}

static void prvTaskThree( void *pvParameters )
{
	for (;;) {
		xil_printf(" Three ");

		vTaskJobEnd();
	}
}

//SOURCED FROM ABSURD BENCHMARK SUITE BY HEAPLAB - POLIMI
//#define SCALING_FACTOR 2
//
//static double hermit_poly(double p_0, double p_1, double p_2, double p_3, double x){
//    double a,b,c,d;
//
//    a = -p_0/2 + (3 *p_1)/2 - (3 *p_2)/2 + p_3/2;
//    b = p_0 - (5 *p_1)/2 + 2*p_2 - p_3/2;
//    c = - p_0/2 +p_2/2;
//    d = p_1;
//
//    return  a*x*x*x + b*x*x +c*x+d;
//}
//
//static unsigned int get_pixel(int x, int y){
//    return mat_in[x][y];
//}
//
//static float get_hour_of_day() {
//	return 6.0;
//}
//
//void replace_old_img() {}
//
//////REAL TIME CAMERA IMAGE ACQUISITION EXAMPLE
//////THE ACQUIRED IMAGE IS UPDATED BEFORE TASK ACTIVATION AND REMAINS STABLE UNTIL THE DEADLINE OF THE TASK
//static void prvImgAcquireAndScaleTask( void *pvParameters )
//{
//	for (;;) {
//		FAULTDET_ExecutionDescriptor inst;
//		FAULTDET_initFaultDetection(&inst);
//
//		float hour=get_hour_of_day();
//		int i,j;
//		for(i=0;i<SCALING_FACTOR*IMG_HEIGHT;i++){
//			for(j=0;j<SCALING_FACTOR*IMG_WIDTH;j++){
//				int x,y, uniIdBase;
//				float dx,dy;
//
//				uniIdBase=i*(SCALING_FACTOR*IMG_HEIGHT)+j;
//
//				x = i/SCALING_FACTOR;
//				y = j/SCALING_FACTOR;
//				dx=i/SCALING_FACTOR-x;
//				dy=j/SCALING_FACTOR-y;
//
//				float col0,col1,col2,col3,res;
//				float i0, i1, i2, i3, accum;
//
//				i0=get_pixel(x-1,y-1);
//				i1=get_pixel(x,y-1);
//				i2=get_pixel(x+1,y-1);
//				i3=get_pixel(x+2,y-1);
//				accum=i0+i1+i2+i3;
//
//				/*check if the sum of the colours of 4 adiacent pixels
//				 is not uncommon for the hour of the day and the coordinates in the image, assuming camera
//				 is fixed and working in a super secure room with restricted access,
//				 so people won't usually enter there*/
//				FAULTDET_testPoint(&inst,
//						uniIdBase+1, //uniId from 1 to 65534 (included)
//						0, //checkId
//						0, /*non blocking.
//										BLOCKING OR NON BLOCKING:
//										if BLOCKING, FAULTDET_blockIfFaultDetectedInTask (see later for details) is called if a test is performed,
//										otherwise, after writing the controlStr to RAM and informing the fault detector
//										that a new controlStr is available, the function returns.*/
//						4, //SIZE OF THIS SPECIFIC AOV (<=FAULTDETECTOR_MAX_AOV_DIM, unused elements will be initialised to 0)
//						&accum, &x, &y, &hour); //values of AOV
//				col0=hermit_poly(i0,i1,i2,i3,dx);
//				FAULTDET_testPoint(&inst,
//						uniIdBase+1, //uniId
//						1, //checkId
//						0, //non blocking
//						6, //SIZE OF THIS SPECIFIC AOV
//						&i0, &i1, &i2, &i3, &col0, &dx); //values of AOV
//
//				i0=get_pixel(x-1,y);
//				i1=get_pixel(x,y);
//				i2=get_pixel(x+1,y);
//				i3=get_pixel(x+2,y);
//				accum=i0+i1+i2+i3;
//				FAULTDET_testPoint(&inst,
//						uniIdBase+2, //uniId
//						0, //checkId
//						0, //non blocking.
//						4, //SIZE OF THIS SPECIFIC AOV
//						&accum, &x, &y, &hour); //values of AOV
//				col1=hermit_poly(i0,i1,i2,i3,dx);
//				FAULTDET_testPoint(&inst,
//						uniIdBase+2, //uniId
//						1, //checkId
//						0, //non blocking
//						6, //SIZE OF THIS SPECIFIC AOV
//						&i0, &i1, &i2, &i3, &col1, &dx); //values of AOV
//
//				i0=get_pixel(x-1,y+1);
//				i1=get_pixel(x,y+1);
//				i2=get_pixel(x+1,y+1);
//				i3=get_pixel(x+2,y+1);
//				accum=i0+i1+i2+i3;
//				FAULTDET_testPoint(&inst,
//						uniIdBase+3, //uniId
//						0, //checkId
//						0, //non blocking.
//						4, //SIZE OF THIS SPECIFIC AOV
//						&accum, &x, &y, &hour); //values of AOV
//				col2=hermit_poly(i0,i1,i2,i3,dx);
//				FAULTDET_testPoint(&inst,
//						uniIdBase+3, //uniId
//						1, //checkId
//						0, //non blocking
//						6, //SIZE OF THIS SPECIFIC AOV
//						&i0, &i1, &i2, &i3, &col2, &dx); //values of AOV
//
//				i0=get_pixel(x-1,y+2);
//				i1=get_pixel(x,y+2);
//				i2=get_pixel(x+1,y+2);
//				i3=get_pixel(x+2,y+2);
//				accum=i0+i1+i2+i3;
//				FAULTDET_testPoint(&inst,
//						uniIdBase+4, //uniId
//						0, //checkId
//						0, //non blocking.
//						4, //SIZE OF THIS SPECIFIC AOV
//						&accum, &x, &y, &hour); //values of AOV
//				col3=hermit_poly(i0,i1,i2,i3,dx);
//				FAULTDET_testPoint(&inst,
//						uniIdBase+4, //uniId
//						1, //checkId
//						0, //non blocking
//						6, //SIZE OF THIS SPECIFIC AOV
//						&i0, &i1, &i2, &i3, &col3, &dx); //values of AOV
//				res=hermit_poly(col0,col1,col2,col3,dy);
//				FAULTDET_testPoint(&inst,
//						uniIdBase+5, //uniId
//						1, //checkId
//						0,
//						6,
//						&col0, &col1, &col2, &col3, &res, &dy);
//
//				mat_out[i][j]=res;
//			}
//		}
//
//		/*we want to commit what we processed. Check no fault has happened.
//			As soon as a fault is detected by fault detector and the condition allows it,
//			task is killed and reexecuted, so we just have to wait here.
//			Most likely, if a fault is detected, we won't reach this point,
//			the task will be re executed earlier.*/
//		FAULTDET_blockIfFaultDetectedInTask(&inst);
//
//		//no fault, commit changes
//		replace_old_img(mat_out);
//
//		//signal to the scheduler the end of the job
//		vTaskJobEnd();
//	}
//}


void printBits(size_t const size, void const * const ptr)
{
	xil_printf(" ");
	unsigned char *b = (unsigned char*) ptr;
	unsigned char byte;
	int i, j;

	for (i = size-1; i >= 0; i--) {
		for (j = 7; j >= 0; j--) {
			byte = (b[i] >> j) & 1;
			xil_printf("%u", byte);
		}
	}
	puts("");
	xil_printf(" ");
}


static void prvTaskFour( void *pvParameters )
{
#ifdef testingCampaign
	xPortSchedulerDisableIntr(); //if uncommented, task will execute continuously
	for (int executionId=-1 ;executionId<96; executionId++) {
#else
		for (;;) {
#endif
#ifndef FAULTDETECTOR_EXECINSW
			FAULTDET_ExecutionDescriptor inst;
			FAULTDET_initFaultDetection(&inst);
#endif

			//		FAULTDET_testing_initTesting();
			//FAULTDET_resetFault(); //not needed, automatically done by the faultdetector when a command from the same check but with different UniId is received

			float v1=150.0;
			float v2=50.0;
			float v3=50.0;

#ifdef testingCampaign

			xil_printf("Exec id %d", executionId);

			if (executionId>=0) {
				printBits(sizeof(u32), &v1);
				FAULTDET_testing_injectFault32(v1, executionId, 0, 31, injectingErrors);
				printBits(sizeof(u32), &v1);

				printBits(sizeof(u32), &v2);
				FAULTDET_testing_injectFault32(v2, executionId, 32, 63, injectingErrors);
				printBits(sizeof(u32), &v2);

				printBits(sizeof(u32), &v3);
				FAULTDET_testing_injectFault32(v3, executionId, 64, 95, injectingErrors);
				printBits(sizeof(u32), &v3);
			}
#endif

			FAULTDET_testPoint(
#ifndef FAULTDETECTOR_EXECINSW
					&inst,
#endif
					1, //uniId
					0, //checkId
					0, //BLOCKING OR NON BLOCKING, non blocking
#ifdef testingCampaign
					injectingErrors,
#endif
					8, //SIZE OF THIS SPECIFIC AOV (<=FAULTDETECTOR_MAX_AOV_DIM , unused elements will be initialised to 0)
					&v1, &v2, &v3, &v3, &v3, &v3, &v3, &v3);

			/*we want to commit what we processed. Check no fault has happened.
			As soon as a fault is detected by fault detector and the condition allows it,
			task is killed and reexecuted, so we just have to wait here.
			Most likely, if a fault is detected, we won't reach this point,
			the task will be re executed earlier.*/
			//		FAULTDET_blockIfFaultDetectedInTask(&inst);

#ifdef testingCampaign
			xil_printf(" total: %d ", FAULTDET_testing_getTotal());
			xil_printf(" ok: %d ", FAULTDET_testing_getOk());
			xil_printf(" fp: %d ", FAULTDET_testing_getFalsePositives());
			xil_printf(" fn: %d ", FAULTDET_testing_getFalseNegatives());

			//after the first execution (generating goldens), inject faults
			injectingErrors=0xFF;
#endif

			//commit changes
			//writeOutput(...)

			//signal to the scheduler the end of the job
#ifndef testingCampaign
			vTaskJobEnd();
#endif
		}
	}
